# crypto_speed_test

When you pull this you should immediately run the following commands:
- pip install --upgrade setuptools
- python setup.py sdist

Once you've done that you can test the result of the script by running:
- python main.py
